

struct node1
{
    struct node1* ptr, * link;
    int age, patient_no;
    char patient_name[50], gender[10], appointment_date[11], appointment_time[6];
};


struct node2
{
    struct node2* link;
    char date[11];
    float weight;
    char disease[100], medicine[50];
};


struct Node
{
    char symptom[100];
    struct Node* yes;
    struct Node* no;
};

void init(struct node1* root, struct node2* top);

void saveDataToFile(const char* file1);

void searchByName(const char* name);

void calculateFee(const char date[]);

void scheduleAppointment();

void add_new_patient();

void add_patient_info();

void display(int number);

void delete_patient(int number);

void identifyDisease(struct Node* root);

struct Node* createNode(const char* symptom);







